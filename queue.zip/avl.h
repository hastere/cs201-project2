#ifndef AVL_H
#define AVL_H
#include "node.h"
#include "bst.h"

extern void insertAVL(bst *, char *);
extern void deleteAVL(bst *, char *);

#endif
